package com.human.view;

import com.human.model.Model;

public interface ViewInterface {
	public void execute(Model model) ;
	
}
